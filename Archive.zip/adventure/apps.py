from django.apps import AppConfig


class AdventureConfig(AppConfig):
    name = 'adventure'
