import React, { useState } from 'react';
import Map from 'Map.js';

const Game = () => {
    return (<div>
        <header>LambdaMUD</header>
        <div>
            <nav></nav>
            <Map />
        </div>
        
    </div>);
}

export default Game;